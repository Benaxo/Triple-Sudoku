﻿using System.Drawing;
using System.Windows.Forms;

namespace TriSudoku
{
    public class ClassChiffre : Label
    {
        public ClassChiffre(int Numero, int ChiffreLeft)
        {
            BackColor = Color.Azure;
            ForeColor = Color.Brown;
            Size = new Size(40, 40);
            Location = new Point(ChiffreLeft, 640);
            BorderStyle = BorderStyle.FixedSingle;
            TextAlign = ContentAlignment.MiddleCenter;
            Font = new Font("Tahoma", 22, FontStyle.Bold);
            Text = Numero.ToString();
        }
    }
}