﻿namespace TriSudoku
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Label1 = new System.Windows.Forms.Label();
            this.Temps = new System.Windows.Forms.Label();
            this.Niveau4 = new System.Windows.Forms.CheckBox();
            this.Niveau3 = new System.Windows.Forms.CheckBox();
            this.Niveau2 = new System.Windows.Forms.CheckBox();
            this.Niveau1 = new System.Windows.Forms.CheckBox();
            this.Cadre = new System.Windows.Forms.PictureBox();
            this.MenuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Solution = new System.Windows.Forms.ToolStripMenuItem();
            this.Recommencer = new System.Windows.Forms.ToolStripMenuItem();
            this.Chronometre = new System.Windows.Forms.Timer(this.components);
            this.InfoJeu = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Cadre)).BeginInit();
            this.MenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(650, 349);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(328, 62);
            this.Label1.TabIndex = 31;
            this.Label1.Text = "Le principe réside dans le fait que les 3 Sudokus soient imbiqués les uns dans la" +
    "s autres ; Le sudoku rouge au centre sert de base pour la construction de celui " +
    "du haut et celui du bas .";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Temps
            // 
            this.Temps.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Temps.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Temps.Location = new System.Drawing.Point(683, 90);
            this.Temps.Name = "Temps";
            this.Temps.Size = new System.Drawing.Size(261, 37);
            this.Temps.TabIndex = 29;
            this.Temps.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Niveau4
            // 
            this.Niveau4.AutoSize = true;
            this.Niveau4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Niveau4.Location = new System.Drawing.Point(828, 533);
            this.Niveau4.Name = "Niveau4";
            this.Niveau4.Size = new System.Drawing.Size(105, 17);
            this.Niveau4.TabIndex = 28;
            this.Niveau4.Text = "4 : Diabolique";
            this.Niveau4.UseVisualStyleBackColor = true;
            this.Niveau4.Click += new System.EventHandler(this.Niveau1_Click);
            // 
            // Niveau3
            // 
            this.Niveau3.AutoSize = true;
            this.Niveau3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Niveau3.Location = new System.Drawing.Point(828, 510);
            this.Niveau3.Name = "Niveau3";
            this.Niveau3.Size = new System.Drawing.Size(88, 17);
            this.Niveau3.TabIndex = 27;
            this.Niveau3.Text = "3 : Difficile";
            this.Niveau3.UseVisualStyleBackColor = true;
            this.Niveau3.Click += new System.EventHandler(this.Niveau1_Click);
            // 
            // Niveau2
            // 
            this.Niveau2.AutoSize = true;
            this.Niveau2.Checked = true;
            this.Niveau2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Niveau2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Niveau2.ForeColor = System.Drawing.Color.Black;
            this.Niveau2.Location = new System.Drawing.Point(828, 487);
            this.Niveau2.Name = "Niveau2";
            this.Niveau2.Size = new System.Drawing.Size(82, 17);
            this.Niveau2.TabIndex = 26;
            this.Niveau2.Text = "2 : Moyen";
            this.Niveau2.UseVisualStyleBackColor = true;
            this.Niveau2.Click += new System.EventHandler(this.Niveau1_Click);
            // 
            // Niveau1
            // 
            this.Niveau1.AutoSize = true;
            this.Niveau1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Niveau1.ForeColor = System.Drawing.Color.Black;
            this.Niveau1.Location = new System.Drawing.Point(828, 464);
            this.Niveau1.Name = "Niveau1";
            this.Niveau1.Size = new System.Drawing.Size(79, 17);
            this.Niveau1.TabIndex = 25;
            this.Niveau1.Text = "1 : Facile";
            this.Niveau1.UseVisualStyleBackColor = true;
            this.Niveau1.Click += new System.EventHandler(this.Niveau1_Click);
            // 
            // Cadre
            // 
            this.Cadre.Location = new System.Drawing.Point(2, 41);
            this.Cadre.Name = "Cadre";
            this.Cadre.Size = new System.Drawing.Size(989, 704);
            this.Cadre.TabIndex = 24;
            this.Cadre.TabStop = false;
            // 
            // MenuStrip1
            // 
            this.MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Solution,
            this.Recommencer});
            this.MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip1.Name = "MenuStrip1";
            this.MenuStrip1.Size = new System.Drawing.Size(1013, 24);
            this.MenuStrip1.TabIndex = 32;
            this.MenuStrip1.Text = "MenuStrip1";
            // 
            // Solution
            // 
            this.Solution.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Solution.Name = "Solution";
            this.Solution.Size = new System.Drawing.Size(125, 20);
            this.Solution.Text = "Solution de la grille";
            this.Solution.Click += new System.EventHandler(this.Solution_Click);
            // 
            // Recommencer
            // 
            this.Recommencer.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Recommencer.Name = "Recommencer";
            this.Recommencer.Size = new System.Drawing.Size(183, 20);
            this.Recommencer.Text = "Recommencer la même grille";
            this.Recommencer.Visible = false;
            this.Recommencer.Click += new System.EventHandler(this.Recommencer_Click);
            // 
            // Chronometre
            // 
            this.Chronometre.Interval = 1000;
            this.Chronometre.Tick += new System.EventHandler(this.Chronometre_Tick);
            // 
            // InfoJeu
            // 
            this.InfoJeu.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InfoJeu.Location = new System.Drawing.Point(637, 142);
            this.InfoJeu.Name = "InfoJeu";
            this.InfoJeu.Size = new System.Drawing.Size(341, 179);
            this.InfoJeu.TabIndex = 40;
            this.InfoJeu.Text = resources.GetString("InfoJeu.Text");
            this.InfoJeu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1013, 746);
            this.Controls.Add(this.InfoJeu);
            this.Controls.Add(this.MenuStrip1);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Temps);
            this.Controls.Add(this.Niveau4);
            this.Controls.Add(this.Niveau3);
            this.Controls.Add(this.Niveau2);
            this.Controls.Add(this.Niveau1);
            this.Controls.Add(this.Cadre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Triple Sudoku";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.Cadre)).EndInit();
            this.MenuStrip1.ResumeLayout(false);
            this.MenuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Temps;
        internal System.Windows.Forms.CheckBox Niveau4;
        internal System.Windows.Forms.CheckBox Niveau3;
        internal System.Windows.Forms.CheckBox Niveau2;
        internal System.Windows.Forms.CheckBox Niveau1;
        internal System.Windows.Forms.PictureBox Cadre;
        internal System.Windows.Forms.MenuStrip MenuStrip1;
        internal System.Windows.Forms.ToolStripMenuItem Solution;
        internal System.Windows.Forms.Timer Chronometre;
        internal System.Windows.Forms.ToolStripMenuItem Recommencer;
        internal System.Windows.Forms.Label InfoJeu;
    }
}

