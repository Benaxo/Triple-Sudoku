﻿using System;
using System.Collections.Generic;

namespace TriSudoku
{
    public class ClassMoteur
    {
        // Il y a 32 Grilles de base : 8 faciles, 8 moyennes, 8 difficiles et 8 diaboliques
        // Chaque grille nécessite 81 cases ( de la case 0 en haut à gauche à la case 80 en bas à droite)
        // Chacune des 32 grilles nécessitent un bloc de 81 valeurs dans la liste DataGrille qui est chargée depuis les ressources du projet
        // Une valeur visible a sa valeur entre 1 et 9 et une valeur invisible à trouver a sa valeur entre 255 et 247 
        // Le chiffre de la case à trouver est obtenu ainsi : 256 - Valeur stockée en Ressources ( la valeur allant de 247 à 255 dans ce cas )
        public static List<ClassCaseJeu> ListCasesJeu = new List<ClassCaseJeu>();
        public static List<byte> ListDataGrille = new List<byte>();
        private static List<int> ListHorizontals, ListVerticals;
        public static int Niveau;
        private static Random Alea;

        /// <summary> 
        /// Initialise le triple sudoku selon le niveau
        /// </summary>
        public static void InitialiseGrille()
        {
            //        Grille rouge                          Grille bleue                                 Grille verte

            //   0  1  2  3  4  5  6  7  8          81  82  83  84  85  86  87  88  89        30  31  32  33  34  35 126 127 128   
            //   9 10 11 12 13 14 15 16 17          90  91  92  93  94  95  96  97  98        39  40  41  42  43  44 129 130 131 
            //  18 19 20 21 22 23 24 25 26          99 100 101 102 103 104 105 106 107        48  49  50  51  52  53 132 133 134
            //  27 28 29 30 31 32 33 34 35         108 109 110   0   1   2   3   4   5        57  58  59  60  61  62 135 136 137
            //  36 37 38 39 40 41 42 43 44         111 112 113   9  10  11  12  13  14        66  67  68  69  70  71 138 139 140
            //  45 46 47 48 49 50 51 52 53         114 115 116  18  19  20  21  22  23        75  76  77  78  79  80 141 142 143  
            //  54 55 56 57 58 59 60 61 62         117 118 119  27  28  29  30  31  32       153 154 155 156 157 158 144 145 156 
            //  63 64 65 66 67 68 69 70 71         120 121 122  36  37  38  39  40  41       159 160 161 162 163 164 147 148 149
            //  72 73 74 75 76 77 78 79 80         123 124 125  45  46  47  48  49  50       165 166 167 168 169 170 150 151 152

            //                                       Les 3 sudokus imbriqués

            //                              81  82  83  84  85  86  87  88  89                                       
            //                              90  91  92  93  94  95  96  97  98
            //                              99 100 101 102 103 104 105 106 107
            //                             108 109 110   0   1   2   3   4   5   6   7   8
            //                             111 112 113   9  10  11  12  13  14  15  16  17
            //                             114 115 116  18  19  20  21  22  23  24  25  26
            //                             117 118 119  27  28  29  30  31  32  33  34  35 126 127 128
            //                             120 121 122  36  37  38  39  40  41  42  43  44 139 130 131
            //                             123 124 125  45  46  47  48  49  50  51  52  53 132 133 134
            //                                          54  55  56  57  58  59  60  61  62 135 136 137
            //                                          63  64  65  66  67  68  69  70  71 138 139 140
            //                                          72  73  74  75  76  77  78  79  80 141 142 143
            //                                                     153 154 155 156 157 158 144 145 146
            //                                                     159 160 161 162 163 164 147 148 149
            //                                                     165 166 167 168 169 170 150 151 152


            // La grille de base est celle en rouge
            // Crée une grille correcte qui va servir de point de départ pour la
            // création d'un Sudoku.Il y a 8 modèles de base pour chaque difficulté
            // afin de donner un maximum de diversité (en effet, même après avoir
            // appliquer la fonction "MelangeGrille", un carré de 3x3 cases vides
            // restera sans aucune indication initiale...)
            List<int> ListChiffres;
            int Hor, Vert, Octet, Min, IndexData, IndexSource, IndexDestination, Source, Destination, Param, IndexDestination1, IndexDestination2, Aleatoire, Compteur;
            Min = (Niveau - 1) * 8; // 0, 8, 16, 24 selon niveau
            Random Alea = new Random(DateTime.Now.Millisecond);
            IndexData = Alea.Next(Min, Min + 7) * 81; // index début du bloc de 81 valeurs pour la grille de jeu
            for (int i = 0; i <= 80; i++)
            {
                 Octet = ListDataGrille[IndexData + i];
                ListCasesJeu[i].Enabled = Octet > 9;
                if (Octet > 9 )
                    Octet = 256 - Octet;
                ListCasesJeu[i].ChiffreSolution = Octet;
                ListCasesJeu[i].ChiffreJoue = 0;
            }
            // On mélange la grille de jeu
            // transposition du puzzle --> 2 possibilités
            // cette opération ne peut pas être obtenue par permutations de lignes
            // les colonnes deviennent les lignes et vice versa
            if (Alea.Next(0, 9) % 2 == 0)
            {
                // on inverse les lignes et les colonnes
                Source = 9;
                Destination = 1;
                for (int i = 0; i <= 7; i++)
                {
                    IndexSource = Source;
                    IndexDestination = Destination;
                    for (int j = 0; j <= i; j++)
                    {
                        EchangeCasesJeu(IndexSource, IndexDestination);
                        IndexSource += 1;
                        IndexDestination += 9;
                    }
                    Source += 9;
                    Destination += 1;
                }
            }
            // lignes "triples" --> (3!)^2 = 36 possibilités ( 3! = factorielle de 3 soit 1 * 2 * 3 = 6 )
            Melange3ValeursHorizontalVertical();
            for (int i = 0; i <= 2; i++)
            {
                Hor = ListHorizontals[i];
                Vert = ListVerticals[i];
                if (i < Hor)
                    EchangeLignesTriple("H", i, Hor - 1);
                if (i < Vert)
                    EchangeLignesTriple("V", i, Vert - 1);
            }
            // lignes "simples" -->(3!)^6 = 46656 possibilités  ( 3! = factorielle de 3 soit 1 * 2 * 3 = 6 )
            for (int j = 0; j <= 2; j++)
            {
                Melange3ValeursHorizontalVertical();
                for (int i = 0; i <= 2; i++)
                {
                    Hor = ListHorizontals[i];
                    Vert = ListVerticals[i];
                    Param = j * 3;
                    if (i < Hor)
                        EchangeLignesSimple("H", Param + i, Param + Hor - 1);
                    if (i < Vert)
                        EchangeLignesSimple("V", Param + i, Param + Vert - 1);
                }
            }
            // échange Chiffres sur la grille finale
            // chiffres --> 9! = 362880 possibilités ( 9! = factorielle de 9 soit 1 * 2 * 3 * 4 * 5 * 6 * 7 * 8 * 9 )
            ListChiffres = Melange(new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 });
            for (int i = 0; i <= 80; i++)
                ListCasesJeu[i].ChiffreSolution = ListChiffres[ListCasesJeu[i].ChiffreSolution - 1];
            // Reste à compléter les cases des Sudokus bleu et vert qui ne sont pas communes avec le Sudoku rouge
            IndexDestination1 = 108;
            IndexDestination2 = 144;
            for (int j = 0; j <= 5; j++)
                for (int i = 0; i <= 2; i++)
                {
                    // les 2 blocs verticaux de 18 cases à gauche et à droite ( sudokus bleu et vert )
                    RemplirCaseJeu(8 - i + (j * 9), IndexDestination1, Alea.Next(1, 18) < 12);
                    RemplirCaseJeu(29 - i + (j * 9), IndexDestination1 + 18, Alea.Next(1, 18) < 12);
                    IndexDestination1++;
                }
            for (int i = 0; i <= 2; i++)
            {
                for (int j = 0; j <= 5; j++)
                {
                    // les 2 blocs horizontaux de 18 cases en haut et en bas ( sudokus bleu et vert )
                    RemplirCaseJeu(3 + j + (i * 9), 165 + j - (i * 6), Alea.Next(1, 18) < 12);
                    RemplirCaseJeu(54 + j + (i * 9), 102 + j - (i * 9), Alea.Next(1, 18) < 12);
                }
                for (int j = 0; j <= 2; j++)
                {
                    // les 2 blocs de 9 cases en haut à gauche et en bas à droite ( sudokus bleu et vert )
                    RemplirCaseJeu(20 - j - (i * 9), IndexDestination2, Alea.Next(1, 9) < 4);
                    IndexDestination2++;
                    RemplirCaseJeu(80 - i - (j * 9), 81 + i + (j * 9), Alea.Next(1, 9) < 4);
                }
            }
            // Permutations entre 2 lignes horizontales ou verticales dans les cases entourant le sudoku rouge du centre
            Compteur = Alea.Next(10, 20);
            List<int> ListIndexCases = new List<int>() { 81, 90, 81, 99, 90, 99, 153, 159, 153, 165, 159, 165, 144, 147, 144, 150, 147, 150, 81, 82, 81, 83, 82, 83, 126, 127, 126, 128, 127, 128, 84, 54, 93, 63, 8, 158, 17, 164, 108, 6, 109, 7, 27, 126, 28, 127 };
            // Permutations de 2 des 3 lignes horizontales en haut du Sudoku bleu
            while (TestCasesDifferentes(ListIndexCases.GetRange(30, 4)) == false)
                for (int i = 0; i <= Compteur; i++)
                {
                    Aleatoire = Alea.Next(0, 2) * 2;
                    for (int j = 0; j <= 8; j++)
                        EchangeCasesJeu(ListIndexCases[Aleatoire] + j, ListIndexCases[Aleatoire + 1] + j);
                }
            // Permutations de 2 des 3 lignes horizontales en bas du sudoku vert
            while (TestCasesDifferentes(ListIndexCases.GetRange(34, 4)) == false)
                for (int i = 0; i <= Compteur; i++)
                {
                    Aleatoire = Alea.Next(0, 2) * 2;
                    for (int j = 0; j <= 5; j++)
                        EchangeCasesJeu(ListIndexCases[Aleatoire + 6] + j, ListIndexCases[Aleatoire + 7] + j);
                    for (int j = 0; j <= 2; j++)
                        EchangeCasesJeu(ListIndexCases[Aleatoire + 12] + j, ListIndexCases[Aleatoire + 13] + j);
                }
            // Permutations de 2 des 3 lignes verticales à gauche de sudoku bleu
            while (TestCasesDifferentes(ListIndexCases.GetRange(38, 4)) == false)
                for (int i = 0; i <= Compteur; i++)
                {
                    Aleatoire = Alea.Next(0, 2) * 2;
                    for (int j = 0; j <= 2; j++)
                        EchangeCasesJeu(ListIndexCases[Aleatoire + 18] + (j * 9), ListIndexCases[Aleatoire + 19] + (j * 9));
                    for (int j = 3; j <= 8; j++)
                        EchangeCasesJeu(ListIndexCases[Aleatoire + 18] + 27 + ((j - 3) * 3), ListIndexCases[Aleatoire + 19] + 27 + ((j - 3) * 3));
                }
            // Permutations de 2 des 3 lignes verticales à droite de sudoku vert
            while (TestCasesDifferentes(ListIndexCases.GetRange(42, 4)) == false)
                for (int i = 0; i <= Compteur; i++)
                {
                    Aleatoire = Alea.Next(0, 2) * 2;
                    for (int j = 0; j <= 8; j++)
                        EchangeCasesJeu(ListIndexCases[Aleatoire + 24] + (j * 3), ListIndexCases[Aleatoire + 25] + (j * 3));
                }
        }

        /// <summary>
        /// Test si 2 groupes de 2 cases sont différents 
        /// Ceci permet de rajouter des groupes de 3 cases horizontaux ou verticaux sans ressemblance avec des groupes de 3 cases existant déjà dans le sudoku de base rouge 
        /// </summary>
        /// <param name="ListIndexCases"></param>
        /// <returns></returns>
        private static bool TestCasesDifferentes(List<int> ListIndexCases)
        {
            return ListCasesJeu[ListIndexCases[0]].ChiffreSolution != ListCasesJeu[ListIndexCases[1]].ChiffreSolution && ListCasesJeu[ListIndexCases[2]].ChiffreSolution != ListCasesJeu[ListIndexCases[3]].ChiffreSolution;
        }

        /// <summary>
        /// Remplit une case de jeu destination avec les informations d'une case de jeu source
        /// </summary>
        /// <param name="IndexSource"></param>
        /// <param name="IndexDestination"></param>
        /// <param name="CaseEnabled"></param>
        private static void RemplirCaseJeu(int IndexSource, int IndexDestination, bool CaseEnabled)
        {
            ListCasesJeu[IndexDestination].ChiffreJoue = 0;
            ListCasesJeu[IndexDestination].ChiffreSolution = ListCasesJeu[IndexSource].ChiffreSolution;
            ListCasesJeu[IndexDestination].Enabled = CaseEnabled;
        }
        
        /// <summary>
        /// Mélange les 3 valeurs 1, 2 et 3 ( 6 possibilités )
        /// </summary>
        private static void Melange3ValeursHorizontalVertical()
        {
            ListHorizontals = Melange(new List<int>() { 1, 2, 3 });
            ListVerticals = Melange(new List<int>() { 1, 2, 3 });
        }

        /// <summary>
        /// Echange entre les propriétés de 2 objets ListCasesJeu()
        /// </summary>
        /// <param name="Index1"></param>
        /// <param name="Index2"></param>
        private static void EchangeCasesJeu(int Index1, int Index2)
        {
            (ListCasesJeu[Index2].ChiffreSolution, ListCasesJeu[Index1].ChiffreSolution) = (ListCasesJeu[Index1].ChiffreSolution, ListCasesJeu[Index2].ChiffreSolution);
            (ListCasesJeu[Index2].ChiffreJoue, ListCasesJeu[Index1].ChiffreJoue) = (ListCasesJeu[Index1].ChiffreJoue, ListCasesJeu[Index2].ChiffreJoue);
            (ListCasesJeu[Index2].Enabled, ListCasesJeu[Index1].Enabled) = (ListCasesJeu[Index1].Enabled, ListCasesJeu[Index2].Enabled);
        }

        /// <summary>
        /// Echange 2x3 lignes horizontales ou verticales dans ListCasesJeu()
        /// </summary>
        /// <param name="TypeLigne"></param>
        /// <param name="Param1"></param>
        /// <param name="Param2"></param>
        private static void EchangeLignesTriple(string TypeLigne, int Param1, int Param2)
        {
            for (int i = 0; i <= 2; i++)
                EchangeLignesSimple(TypeLigne, (Param1 * 3) + i, (Param2 * 3) + i);
        }

        /// <summary>
        /// Echange 2 lignes horizontales ou verticales dans ListCasesJeu()
        /// </summary>
        /// <param name="TypeLigne"></param>
        /// <param name="Param1"></param>
        /// <param name="Param2"></param>
        private static void EchangeLignesSimple(string TypeLigne, int Param1, int Param2)
        {
            int Index1, Index2;
            for (int i = 0; i <= 8; i++)
            {
                Index1 = (TypeLigne == "H" ? (i * 9) + Param1 : (Param1 * 9) + i);
                Index2 = (TypeLigne == "H" ? (i * 9) + Param2 : (Param2 * 9) + i);
                EchangeCasesJeu(Index1, Index2);
            }
        }

        /// <summary>
        /// Mélange d'une liste d'Integer
        /// </summary>
        /// <param name="ListValeurs"></param>
        /// <returns></returns>
        private static List<int> Melange(List<int> ListValeurs) 
        {
            int Aleatoire;
            Alea = new Random(DateTime.Now.Millisecond);
            for (int i = 0; i < 100; i++)
            {
                Aleatoire = Alea.Next(0, ListValeurs.Count - 1);
                ListValeurs.Add(ListValeurs[Aleatoire]);
                ListValeurs.RemoveAt(Aleatoire);
            }
            return ListValeurs;
        }
    }
}