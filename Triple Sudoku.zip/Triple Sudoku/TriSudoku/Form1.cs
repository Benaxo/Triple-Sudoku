﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.ComponentModel;

namespace TriSudoku
{
    public partial class Form1 : Form
    {
        private readonly List<Color> ListCouleurs = new List<Color>() { Color.Cyan, Color.Red, Color.LimeGreen };
        private List<byte>  ListIndexLignesRouges, ListIndexColonnesRouges, ListIndexCagesRouges, ListIndexLignesBleues, ListIndexColonnesBleues, ListIndexCagesBleues, ListIndexLignesVertes, ListIndexColonnesVertes, ListIndexCagesVertes;
        private readonly List<Label> ListCasesChiffre = new List<Label>();
        private CheckBox Selection;
        private Label CaseChiffre;
        private DateTime TpsHorloge;
        private int NumeroCase, CaseLeft, CaseTop, Chiffre, IndexLigne, IndexColonne, IndexCage, IndexClick;
        private bool FlagDoublon, FlagSolution;

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Chargement de la form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            NumeroCase = 0;
            // les cases du jeu
            ClassChiffre CaseChiffre;
            int ChiffreLeft = 143;
            CaseTop = 141;
            // le Sudoku rouge ( cases 0 à 80 )
            for (int Row = 0; Row <= 8; Row++)
            {
                CaseLeft = 141;
                for (int Col = 0; Col <= 8; Col++)
                {
                    CreationCaseJeu();
                    if (Col == 2 | Col == 5)
                        CaseLeft += 2;
                }
                CaseTop += 40;
                if (Row == 2 | Row == 5)
                    CaseTop += 2;
            }
            // les 3 lignes du haut du Sudoku bleu ( cases 81 à 107)
            CaseTop = 19;
            for (int Row = 0; Row <= 2; Row++)
            {
                CaseLeft = 19;
                for (int Col = 0; Col <= 8; Col++)
                {
                    CreationCaseJeu();
                    if (Col == 2 | Col == 5)
                        CaseLeft += 2;
                }
                CaseTop += 40;
            }
            // les 18 cases du sudoku bleu sur la gauche du sudoku rouge ( cases 108 à 125)
            CaseTop = 141;
            for (int Row = 0; Row <= 5; Row++)
            {
                CaseLeft = 19;
                for (int Col = 0; Col <= 2; Col++)
                    CreationCaseJeu();
                CaseTop += 40;
                if (Row == 2)
                    CaseTop += 2;
            }
            // verticalement les 27 cases du sudoku vert à droite du sudoku rouge ( cases 126 à 152)
            CaseTop = 263;
            for (int Row = 0; Row <= 8; Row++)
            {
                CaseLeft = 507;
                for (int Col = 0; Col <= 2; Col++)
                    CreationCaseJeu();
                CaseTop += 40;
                if (Row == 2 | Row == 5)
                    CaseTop += 2;
            }
            // les 3 lignes du bas du Sudoku vert : les 18 cases à gauche uniquement ( cases 153 à 170)
            CaseTop = 507;
            for (int Row = 0; Row <= 2; Row++)
            {
                CaseLeft = 263;
                for (int Col = 0; Col <= 5; Col++)
                {
                    CreationCaseJeu();
                    if (Col == 2)
                        CaseLeft += 2;
                }
                CaseTop += 40;
            }
            // On affiche les chiffres de 1 à 9 pour sélectionner le chiffre joué
            for (int i = 1; i <= 9; i++)
            {
                CaseChiffre = new ClassChiffre(i, ChiffreLeft);
                ListCasesChiffre.Add(CaseChiffre);
                Cadre.Controls.Add(CaseChiffre);
                CaseChiffre.Click += CaseChiffreClick;
                ChiffreLeft += 40;
            }
            // on trace les contours des 3 Sudokus ainsi que les sépartions entre les régions de 9 cases si nécessaire
            Bitmap CadreJeu = new Bitmap(Cadre.Width, Cadre.Height);
            Graphics G = Graphics.FromImage(CadreJeu);
            G.Clear(BackColor);
            Cadre.Image = CadreJeu;
            G.Dispose();
            CadreJeu = new Bitmap(Cadre.Image);
            for (int i = 0; i <= 2; i++)
            {
                TraceContour(CadreJeu, ListCouleurs[i], 17 + (i * 122), 17 + (i * 122), 368, 3);
                TraceContour(CadreJeu, ListCouleurs[i], 17 + (i * 122), 383 + (i * 122), 368, 3);
                TraceContour(CadreJeu, ListCouleurs[i], 17 + (i * 122), 17 + (i * 122), 3, 368);
                TraceContour(CadreJeu, ListCouleurs[i], 383 + (i * 122), 17 + (i * 122), 3, 368);
            }
            List<int> ListCoordonnees = new List<int>() { 139, 19, 261, 19, 261, 139, 383, 383, 383, 505, 505, 505, 19, 139, 19, 261, 141, 261, 383, 383, 505, 383, 505, 505 };
            for (int i = 0; i <= 5; i++)
            {
                TraceContour(CadreJeu, Color.Yellow, ListCoordonnees[i * 2], ListCoordonnees[(i * 2) + 1], 3, 120);
                TraceContour(CadreJeu, Color.Yellow, ListCoordonnees[(i * 2) + 12], ListCoordonnees[(i * 2) + 13], 120, 3);
            }
            ClassMoteur.Niveau = 2;
            FlagSolution = false;
            // on récupère les Data en ressources
            List<byte> ListParametres = Properties.Resources.FichierData.ToList();
            // on crée les 32 grilles de base
            ClassMoteur.ListDataGrille = ListParametres.GetRange(0, 2592);
            // on crée la liste des cases dans les 9 lignes pour les 3 sudokus
            ListIndexLignesRouges = ListParametres.GetRange(2592, 81);
            ListIndexLignesBleues = ListParametres.GetRange(2673, 81);
            ListIndexLignesVertes = ListParametres.GetRange(2754, 81);
            // on crée la liste des cases dans les 9 colonnes pour les 3 sudokus
            ListIndexColonnesRouges = ListParametres.GetRange(2835, 81);
            ListIndexColonnesBleues = ListParametres.GetRange(2916, 81);
            ListIndexColonnesVertes = ListParametres.GetRange(2997, 81);
            // on crée la liste des cases dans les 9 cages pour les 3 sudokus
            ListIndexCagesRouges = ListParametres.GetRange(3078, 81);
            ListIndexCagesBleues = ListParametres.GetRange(3159, 81);
            ListIndexCagesVertes = ListParametres.GetRange(3240, 81);
        }

        /// <summary>
        /// Affichage de la form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Shown(object sender, EventArgs e)
        {
            InitialiseSelection();
        }

        /// <summary>
        /// Création d'une case du jeu
        /// </summary>
        private void CreationCaseJeu()
        {
            ClassCaseJeu CaseJeu = new ClassCaseJeu(NumeroCase, CaseLeft, CaseTop);
            CaseJeu.Click += CaseJeuClick;
            ClassMoteur.ListCasesJeu.Add(CaseJeu);
            Cadre.Controls.Add(CaseJeu);
            CaseLeft += 40;
            NumeroCase += 1;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CadreJeu"></param>
        /// <param name="Couleur"></param>
        /// <param name="X1"></param>
        /// <param name="Y1"></param>
        /// <param name="Largeur"></param>
        /// <param name="Hauteur"></param>
        private void TraceContour(Bitmap CadreJeu, Color Couleur, int X1, int Y1, int Largeur, int Hauteur)
        {
            Graphics G = Graphics.FromImage(CadreJeu);
            G.FillRectangle(new SolidBrush(Couleur), X1, Y1, Largeur, Hauteur);
            Cadre.Image = CadreJeu;
            G.Dispose();
        }

        /// <summary>
        /// Sélection niveaux 1, 2, 3 ou 4
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Niveau1_Click(object sender, EventArgs e)
        {
            Niveau1.Checked = false;
            Niveau2.Checked = false;
            Niveau3.Checked = false;
            Niveau4.Checked = false;
            Selection = (CheckBox)sender;
            Selection.Checked = true;
            ClassMoteur.Niveau = Convert.ToInt32(Selection.Text.Substring(0, 1));
            InitialiseSelection();
        }

        /// <summary>
        /// Initialisation selon le niveau
        /// </summary>
        private void InitialiseSelection()
        {
            foreach (ClassCaseJeu CaseJeu in ClassMoteur.ListCasesJeu)
            {
                CaseJeu.ChiffreJoue = 0;
                CaseJeu.Text = string.Empty;
            }
            // Réinitialise le chrono
            Chronometre.Enabled = false;
            Chronometre.Stop();
            Temps.Text = "00:00:00";
            // on initialise la triple grille de jeu selon le niveau
            ClassMoteur.InitialiseGrille();
            // on affiche le triple sudoku
            foreach (ClassCaseJeu CaseJeu in ClassMoteur.ListCasesJeu)
                if (CaseJeu.Enabled == false)
                {
                    CaseJeu.Text = CaseJeu.ChiffreSolution.ToString();
                    CaseJeu.ChiffreJoue = CaseJeu.ChiffreSolution;
                }
            Recommencer.Visible = false;
            DepartTimer();
        }

        /// <summary>
        /// Le joueur clique sur un chiffre pour le sélectionner
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CaseChiffreClick(object sender, EventArgs e)
        {
            foreach (Label Chiffre in ListCasesChiffre)
                Chiffre.BackColor = Color.Azure;
            CaseChiffre = (Label)sender;
            Chiffre = Convert.ToInt32(CaseChiffre.Text); // chiffre de 0 à 9
            CaseChiffre.BackColor = Color.Aqua; // trace du chiffre sélectionné en bleu
        }

        /// <summary>
        /// Sélection d'une case du jeu par le joueur pour y placer un chiffre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CaseJeuClick(object sender, EventArgs e)
        {
            if (FlagSolution == true)
                return;
            FlagDoublon = false;
            ClassCaseJeu CaseClick = (ClassCaseJeu)sender;
            IndexClick = CaseClick.Index;
            if (CaseClick.Text != string.Empty && (CaseClick.ForeColor == Color.Red || CaseClick.ForeColor == Color.Black))
            {
                // on efface la case
                CaseClick.ChiffreJoue = 0;
                CaseClick.Text = string.Empty;
            }
            else
            {
                CaseClick.ChiffreJoue = Chiffre;
                CaseClick.Text = Chiffre.ToString();
                TestDoublons(ListIndexLignesRouges, ListIndexColonnesRouges, ListIndexCagesRouges);
                if (FlagDoublon == false)
                    TestDoublons(ListIndexLignesBleues, ListIndexColonnesBleues, ListIndexCagesBleues);
                if (FlagDoublon == false)
                    TestDoublons(ListIndexLignesVertes, ListIndexColonnesVertes, ListIndexCagesVertes);
                CaseClick.ForeColor = FlagDoublon == true ? Color.Red : Color.Black;
                // si pas de doublon toutes les cases sont-elles remplies ?
                if (FlagDoublon == false && ClassMoteur.ListCasesJeu.FindIndex(p => p.Text == string.Empty) == -1)
                {
                    Chronometre.Enabled = false;
                    Chronometre.Stop();
                    MessageBox.Show("Bravo ! Vous avez gagné !!!!!", " Victoire !!!!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        /// <summary>
        /// Test doublons pour les 3 sudokus selon la case de jeu sélectionnée
        /// </summary>
        /// <param name="ListIndexLignes"></param>
        /// <param name="ListIndexColonnes"></param>
        /// <param name="ListIndexCages"></param>
        private void TestDoublons(List<byte> ListIndexLignes, List<byte> ListIndexColonnes, List<byte> ListIndexCages)
        {
            IndexLigne = ListIndexLignes.FindIndex(p => p == IndexClick);
            IndexColonne = ListIndexColonnes.FindIndex(p => p == IndexClick);
            IndexCage = ListIndexCages.FindIndex(p => p == IndexClick);
            if (IndexLigne != -1 && IndexColonne != -1 && IndexCage != -1)
            {
                // la case cliquée appartient au sudoku
                int IndexCase;
                // Test des chiffres dans la ligne pour recherche doublon
                IndexCase = (IndexLigne / 9) * 9;
                ListIndexLignes = ListIndexLignes.GetRange(IndexCase, 9);
                TestDoublonValeur(ListIndexLignes);
                if (FlagDoublon == true)
                    return;
                // Test des chiffres dans la colonne pour recherche doublon
                IndexCase = (IndexColonne / 9) * 9;
                ListIndexColonnes = ListIndexColonnes.GetRange(IndexCase, 9);
                TestDoublonValeur(ListIndexColonnes);
                if (FlagDoublon == true)
                    return;
                // Test des chiffres dans la cage pour recherche doublon
                IndexCase = (IndexCage / 9) * 9;
                ListIndexCages = ListIndexCages.GetRange(IndexCase, 9);
                TestDoublonValeur(ListIndexCages);
            }
        }

        /// <summary>
        /// Test dans une ligne ou une colonne ou une cage pour valeur en double 
        /// </summary>
        /// <param name="ListIndex"></param>
        private void TestDoublonValeur(List<byte> ListIndex)
        {
            string Value;
            List<string> ListValeurs = new List<string>();
            for (int i = 0; i < 9; i++)
            {
                Value = ClassMoteur.ListCasesJeu[ListIndex[i]].Text;
                if (Value != string.Empty)
                {
                    if (ListValeurs.Contains(Value) == true)
                    {
                        // en double dans la ligne
                        FlagDoublon = true;
                        break;
                    }
                    else
                        ListValeurs.Add(Value);
                }
            }
        }

        /// <summary>
        /// On affiche la solution
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Solution_Click(object sender, EventArgs e)
        {
            StopTimer();
            FlagSolution = true;
            foreach (ClassCaseJeu CaseJeu in ClassMoteur.ListCasesJeu)
            {
                CaseJeu.Text = CaseJeu.ChiffreSolution.ToString();
                CaseJeu.ForeColor = Color.Black;
            }
            foreach (Label LabelChiffre in ListCasesChiffre)
                LabelChiffre.Visible = false;
            Recommencer.Visible = true;
        }

        /// <summary>
        /// On recommence le même Sudoku
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Recommencer_Click(object sender, EventArgs e)
        {
            StopTimer();
            FlagSolution = false;
            foreach (Label LabelChiffre in ListCasesChiffre)
            {
                LabelChiffre.BackColor = Color.Azure;
                LabelChiffre.Visible = true;
            }
            foreach (ClassCaseJeu CaseJeu in ClassMoteur.ListCasesJeu)
            {
                CaseJeu.Text = CaseJeu.ChiffreSolution.ToString();
                CaseJeu.ChiffreJoue = CaseJeu.ChiffreSolution;
                if (CaseJeu.Enabled == true)
                {
                    CaseJeu.ChiffreJoue = 0;
                    CaseJeu.Text = string.Empty;
                }
            }
            Recommencer.Visible = false;
            DepartTimer();
        }

        /// <summary>
        /// Démarrage chrono
        /// </summary>
        private void DepartTimer()
        {
            TpsHorloge = DateTime.Now;
            Chronometre.Start();
        }

        /// <summary>
        /// Arrêt du chrono
        /// </summary>
        private void StopTimer()
        {
            Chronometre.Stop();
            Temps.Text = "00:00:00";
        }

        /// <summary>
        /// Affichage du chronomètre
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Chronometre_Tick(object sender, EventArgs e)
        {
            Temps.Text = (DateTime.Now - TpsHorloge).ToString("c").Substring(0, 8);
            Temps.Refresh();
        }
    }
}
