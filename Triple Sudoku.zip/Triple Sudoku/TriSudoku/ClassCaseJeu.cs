﻿using System.Drawing;
using System.Windows.Forms;

namespace TriSudoku
{
    public class ClassCaseJeu : Label
    {
        public int ChiffreSolution { get; set; } // chiffre de la solution
        public int ChiffreJoue { get; set; } // chiffre joué
        public int Index { get; set; }

        /// <summary>
        /// Initialisation d'une case du jeu(hérite de la classe Label )
        /// </summary>
        /// <param name="CaseLeft"></param>
        /// <param name="CaseTop"></param>
        public ClassCaseJeu(int NumeroCase,int CaseLeft, int CaseTop)
        {
            Name = "Case" + NumeroCase.ToString();
            Index = NumeroCase;
            BackColor = Color.Azure;
            Size = new Size(40, 40);
            Location = new Point(CaseLeft, CaseTop);
            BorderStyle = BorderStyle.FixedSingle;
            TextAlign = ContentAlignment.MiddleCenter;
            Font = new Font("Tahoma", 22, FontStyle.Bold);
            ChiffreSolution = 0;
            Enabled = false;
            ChiffreJoue = 0;
        }
    }
}